import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
    getDatabase, ref, onValue, remove, get
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import {
    getAuth, onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// !!! Replace with your actual Firebase configuration !!!
const firebaseConfig = {
    apiKey: "AIzaSyBrV_RYGOZqu_PBVDcbBJjmXxmUX4NEc5w", 
    authDomain: "gvmm-57297.firebaseapp.com",
    databaseURL: "https://gvmm-57297-default-rtdb.firebaseio.com",
    projectId: "gvmm-57297",
    storageBucket: "gvmm-57297.appspot.com",
    messagingSenderId: "128465029455",
    appId: "1:128465029455:web:5fe5bf87f0364edb631d3a"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

// --- Global State and Elements ---
let allFamilies = [];
let currentUID = null;
const list = document.getElementById("familyList");
const searchInput = document.getElementById("searchInput");

// --- Utility Functions ---

/**
 * Displays a toast notification with type support (info, success, error).
 */
function showToast(message, type = "info", duration = 3000) {
    const toast = document.getElementById("toast");
    if (!toast) return;

    clearTimeout(window.currentToastTimeout);

    // Use toast classes for styling
    toast.className = `toast ${type}`;
    toast.textContent = message;

    setTimeout(() => toast.classList.add("show"), 50); 

    window.currentToastTimeout = setTimeout(() => {
        toast.classList.remove("show");
    }, duration);
}

// ✅ Util: paragraph creator
function makePara(label, value) {
    const p = document.createElement("p");
    p.innerHTML = `<strong>${label}:</strong> <span>${value || "-"}</span>`;
    return p;
}

// ✅ Util: button creator
function makeButton(text, handler, className) {
    const btn = document.createElement("button");
    btn.textContent = text;
    if (className) {
        btn.className = className;
    }
    // Prevent event propagation so click doesn't bubble up to card container
    btn.addEventListener("click", (e) => {
        e.stopPropagation();
        handler?.();
    });
    return btn;
}

// --- Render Logic (Async to handle member count) ---

async function render(filteredList) {
    list.innerHTML = "";

    if (filteredList.length === 0) {
        // Render appropriate message based on filter state
        list.innerHTML = searchInput.value.trim() !== '' 
            ? `<div class="no-data">🔍 कोई मैचिंग परिवार नहीं मिला</div>` 
            : `<div class="no-data">🗒️ कोई परिवार नहीं मिला। ➕ Add टैब से एक नया परिवार जोड़ें।</div>`;
        return;
    }

    // Use Promise.all to fetch member counts concurrently and preserve order
    const familyCardPromises = filteredList.map(async (family) => {
        // Fetch member count
        const memberSnap = await get(ref(db, `surveys/members/${currentUID}/${family.key}`));
        const memberCount = memberSnap.exists() ? Object.keys(memberSnap.val()).length : 0;

        // --- Create Card Elements ---
        const div = document.createElement("div");
        div.className = "member-card";

        // Primary Display: Name, Pariwar Sankhya, Member Count
        div.appendChild(makePara("नाम", family.familyName));
        div.appendChild(makePara("परिवार संख्या", family.pariwarSankhya));
        div.appendChild(makePara("सदस्य", memberCount));

        // Toggle Details Button
        const toggleDetailsBtn = makeButton("🔽 Show Details", null, "toggleDetailsBtn");
        div.appendChild(toggleDetailsBtn);

        // More Details Container
        const moreDetails = document.createElement("div");
        moreDetails.className = "more-details";
        moreDetails.style.display = "none"; // Initially hidden

        moreDetails.appendChild(makePara("जन आधार", family.janAadhar));
        moreDetails.appendChild(makePara("स्थान", family.location));
        moreDetails.appendChild(makePara("धर्म", family.dharm));

        // Action Row (View Members, Add Member, Options)
        const actionRow = document.createElement("div");
        actionRow.className = "action-row";

        actionRow.appendChild(makeButton(`👁 सदस्य देखें (${memberCount})`, () => {
            window.location.href = `../showmember/show_member.html?family=${family.key}`;
        }));

        actionRow.appendChild(makeButton("➕ सदस्य जोड़ें", () => {
            window.location.href = `../addmember/add_member.html?family=${family.key}`;
        }));

        // Toggle Options Button
        const toggleActionBtn = makeButton("⚙️ Options", null);
        actionRow.appendChild(toggleActionBtn);

        // Hidden Edit/Delete Buttons
        const actionButtons = document.createElement("div");
        actionButtons.className = "action-buttons";
        actionButtons.style.display = "none"; // Initially hidden

        actionButtons.appendChild(makeButton("✏️ Edit Family", () => {
            // Assuming a family form page exists for editing
            window.location.href = `../addFamily/add_family.html?family=${family.key}`;
        }, "edit-btn"));

        actionButtons.appendChild(makeButton("🗑️ Delete Family", async () => {
            const confirmed = confirm(`क्या आप वाकई मुखिया "${family.familyName}" के परिवार को हटाना चाहते हैं? यह परिवार के सभी सदस्यों को भी हटा देगा।`);
            if (!confirmed) return;

            try {
                // Remove family entry
                await remove(ref(db, `surveys/families/${currentUID}/${family.key}`));
                // Remove all members of this family
                await remove(ref(db, `surveys/members/${currentUID}/${family.key}`));
                showToast("✅ परिवार सफलतापूर्वक हटाया गया", 'success');
            } catch (err) {
                console.error("❌ हटाने में त्रुटि:", err);
                showToast("❌ हटाने में त्रुटि हुई", 'error');
            }
        }, "delete-btn"));

        // --- Attach Listeners ---

        toggleDetailsBtn.addEventListener("click", () => {
            const isHidden = moreDetails.style.display === "none";
            moreDetails.style.display = isHidden ? "flex" : "none";
            toggleDetailsBtn.textContent = isHidden ? "🔼 Hide Details" : "🔽 Show Details";
        });

        toggleActionBtn.addEventListener("click", () => {
            const isHidden = actionButtons.style.display === "none";
            actionButtons.style.display = isHidden ? "flex" : "none";
        });

        moreDetails.appendChild(actionRow);
        moreDetails.appendChild(actionButtons);
        div.appendChild(moreDetails);

        return div;
    });

    // Wait for all cards to be created and append them to the list
    const familyCards = await Promise.all(familyCardPromises);
    familyCards.forEach(card => list.appendChild(card));
}

// --- Initialization and Event Handlers ---

onAuthStateChanged(auth, (user) => {
    if (!user) {
        showToast("कृपया लॉगिन करें", 'info');
        setTimeout(() => {
            window.location.href = "../index.html";
        }, 3000);
        return;
    }

    currentUID = user.uid;
    const familyRef = ref(db, `surveys/families/${currentUID}`);

    // Initial Data Fetch and Live Updates
    onValue(familyRef, (snapshot) => {
        // Show loading state while data is processed
        list.innerHTML = '<div class="loader"></div><p class="loading-text">🔄 डेटा लोड हो रहा है...</p>';
        allFamilies = [];

        if (snapshot.exists()) {
            snapshot.forEach((childSnap) => {
                allFamilies.push({ ...childSnap.val(), key: childSnap.key });
            });

            // Re-render when data changes
            // Filter by search input value (if any)
            const value = searchInput.value.toLowerCase();
            const filtered = allFamilies.filter(f =>
                (f.familyName && f.familyName.toLowerCase().includes(value)) ||
                (f.janAadhar && f.janAadhar.toLowerCase().includes(value))
            );
            render(filtered);
            showToast("✅ परिवार सूची अपडेट की गई", 'success', 1500);
        } else {
            allFamilies = [];
            list.innerHTML = `<div class="no-data">🗒️ कोई परिवार नहीं मिला। ➕ Add टैब से एक नया परिवार जोड़ें।</div>`;
        }
    });

    // Search Listener (Outside onValue)
    searchInput.addEventListener("input", () => {
        const value = searchInput.value.toLowerCase();
        const filtered = allFamilies.filter(f =>
            (f.familyName && f.familyName.toLowerCase().includes(value)) ||
            (f.janAadhar && f.janAadhar.toLowerCase().includes(value))
        );
        // Render filtered data
        render(filtered);
    });
});

// --- Network Status ---
window.addEventListener("offline", () => {
    showToast("❌ इंटरनेट कनेक्शन नहीं है", 'error', 5000);
});
window.addEventListener("online", () => {
    showToast("✅ आप वापस ऑनलाइन हैं", 'success', 3000);
});