// ✅ Modular, Resilient & Maintainable `add_member.js`
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getDatabase, ref, get, push, set } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// --- 1. CONFIGURATION AND INITIALIZATION ---

const firebaseConfig = {
    apiKey: "AIzaSyBrV_RYGOZqu_PBVDcbBJjmXxmUX4NEc5w",
    authDomain: "gvmm-57297.firebaseapp.com",
    databaseURL: "https://gvmm-57297-default-rtdb.firebaseio.com",
    projectId: "gvmm-57297",
    storageBucket: "gvmm-57297.appspot.com",
    messagingSenderId: "128465029455",
    appId: "1:128465029455:web:5fe5bf87f0364edb631d3a"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

// --- 2. GLOBAL ELEMENTS AND STATE ---
const params = new URLSearchParams(window.location.search);
const familyKey = params.get("family");
const memberKey = params.get("member"); // Null if adding new
let currentUID = null;

const memberForm = document.getElementById("memberForm");
const saveMemberBtn = document.getElementById("saveMemberBtn");
const toast = document.getElementById("toast");
const ERROR_CLASS = 'has-error';

// Modal Elements
const actionModal = document.getElementById("actionModal");
const addAnotherMemberBtn = document.getElementById("addAnotherMemberBtn");
const finishSurveyBtn = document.getElementById("finishSurveyBtn");

// Input elements (for easy access and error handling)
const aadhaarInput = document.getElementById("aadhaar");
const nameInput = document.getElementById("member_name");
const fatherNameInput = document.getElementById("father_name");
const dobInput = document.getElementById("dob");
// Select the nearest parent element that can receive the error class for fieldsets
const genderFieldset = document.querySelector('input[name="gender"]').closest('.fieldset-group');
const maritalFieldset = document.querySelector('input[name="marital"]').closest('.fieldset-group');


// --- 3. UTILITY AND UI FUNCTIONS ---

/**
 * Displays a toast notification with type support.
 */
function showToast(message, type = "info", duration = 3000) {
    if (!toast) return;

    clearTimeout(window.currentToastTimeout);

    toast.className = `toast ${type}`;
    toast.textContent = message;

    setTimeout(() => toast.classList.add("show"), 50); 

    window.currentToastTimeout = setTimeout(() => {
        toast.classList.remove("show");
    }, duration);
}

/**
 * Sets the loading state on the submit button.
 */
function setLoading(isLoading) {
    if (!saveMemberBtn) return;
    saveMemberBtn.disabled = isLoading;
    saveMemberBtn.classList.toggle("loading", isLoading);
    saveMemberBtn.setAttribute("aria-busy", isLoading);
}

/**
 * Applies visual error state to an input/fieldset and displays the message.
 */
function applyErrorState(element, message) {
    const formGroup = element.closest('.form-group');
    if (!formGroup) return;

    formGroup.classList.add(ERROR_CLASS);

    const errorEl = formGroup.querySelector(".error-message");
    if (errorEl) {
        errorEl.textContent = message;
    }
}

/**
 * Clears error state from a specific form group.
 */
function clearError(element) {
    const formGroup = element.closest('.form-group');
    if (!formGroup) return;

    formGroup.classList.remove(ERROR_CLASS);
    const errorEl = formGroup.querySelector(".error-message");
    if (errorEl) {
        errorEl.textContent = "";
    }
}

/**
 * Clears all form inputs and error messages.
 */
function resetForm() {
    memberForm.reset();
    clearError(aadhaarInput);
    clearError(nameInput);
    clearError(fatherNameInput);
    clearError(dobInput);
    clearError(genderFieldset); 
    clearError(maritalFieldset);

    aadhaarInput.focus();
}

/**
 * Helper function to show and hide the modal
 */
function toggleModal(show) {
    if (actionModal) {
        actionModal.classList.toggle('visible', show);
    }
}


// --- 4. DATA FETCH (EDIT MODE) ---

async function fetchMemberData(uid) {
    if (!memberKey) return;

    const memberRef = ref(db, `surveys/members/${uid}/${familyKey}/${memberKey}`);

    try {
        const snap = await get(memberRef);
        if (snap.exists()) {
            const data = snap.val();
            memberForm.member_name.value = data.name || "";
            memberForm.father_name.value = data.fatherName || "";
            memberForm.aadhaar.value = data.aadhaar || "";
            memberForm.dob.value = data.dob || "";

            // ✅ Invalid left-hand side in assignment त्रुटि का समाधान
            const genderInput = memberForm.querySelector(`input[name="gender"][value="${data.gender}"]`);
            if (genderInput) {
                 genderInput.checked = true;
            }

            const maritalInput = memberForm.querySelector(`input[name="marital"][value="${data.marital}"]`);
            if (maritalInput) {
                maritalInput.checked = true;
            }
            // ❌ पुरानी त्रुटि वाली लाइनें:
            // memberForm.querySelector(`input[name="gender"][value="${data.gender}"]`)?.checked = true;
            // memberForm.querySelector(`input[name="marital"][value="${data.marital}"]`)?.checked = true;


            showToast("ℹ️ सदस्य विवरण लोड किया गया", 'info');
        } else {
            showToast("❌ सदस्य डेटा नहीं मिला", 'error');
        }
    } catch (error) {
        console.error("Error fetching member data:", error);
        showToast("❌ डेटा लोड करने में त्रुटि हुई", 'error');
    }
}


// --- 5. SUBMISSION LOGIC ---

async function handleMemberSubmit(e) {
    // पेज को रीलोड होने से रोकता है
    e.preventDefault(); 
    setLoading(true);

    // 5.1. Clear previous errors
    clearError(aadhaarInput);
    clearError(nameInput);
    clearError(fatherNameInput);
    clearError(dobInput);
    clearError(genderFieldset);
    clearError(maritalFieldset);

    // 5.2. Get values
    const aadhaar = aadhaarInput.value.trim();
    const name = nameInput.value.trim();
    const fatherName = fatherNameInput.value.trim();
    const dob = dobInput.value;
    const genderValue = memberForm.querySelector('input[name="gender"]:checked')?.value;
    const maritalValue = memberForm.querySelector('input[name="marital"]:checked')?.value;

    let hasError = false;

    // 5.3. Validation
    if (!/^[0-9]{12}$/.test(aadhaar)) {
        applyErrorState(aadhaarInput, "कृपया 12 अंकों का सही आधार नंबर दर्ज करें।");
        hasError = true;
    }
    if (!name) {
        applyErrorState(nameInput, "कृपया नाम दर्ज करें।");
        hasError = true;
    }
    if (!fatherName) {
        applyErrorState(fatherNameInput, "कृपया पिता का नाम दर्ज करें।");
        hasError = true;
    }
    if (!dob) {
        applyErrorState(dobInput, "कृपया जन्म तिथि चुनें।");
        hasError = true;
    }
    if (!genderValue) {
        applyErrorState(genderFieldset, "कृपया लिंग चुनें।");
        hasError = true;
    }
    if (!maritalValue) {
        applyErrorState(maritalFieldset, "कृपया वैवाहिक स्थिति चुनें।");
        hasError = true;
    }

    if (hasError) {
        setLoading(false);
        showToast("❌ कृपया सभी फ़ील्ड सही से भरें।", 'error', 4000); 
        return;
    }

    // 5.4. Data preparation and saving
    const data = {
        name,
        fatherName,
        aadhaar,
        dob,
        gender: genderValue,
        marital: maritalValue,
        timestamp: new Date().toISOString()
    };

    const membersBaseRef = ref(db, `surveys/members/${currentUID}/${familyKey}`);

    const targetMemberRef = memberKey
        ? ref(db, `surveys/members/${currentUID}/${familyKey}/${memberKey}`)
        : push(membersBaseRef);

    try {
        await set(targetMemberRef, data);

        if (!memberKey) {
            showToast("✅ सदस्य सफलतापूर्वक जोड़ा गया!", 'success', 3000);
            toggleModal(true); 
        } else {
            showToast("✅ सदस्य सफलतापूर्वक अपडेट किया गया!", 'success', 3000);
            setTimeout(() => {
                window.location.href = `../showmember/show_member.html?family=${familyKey}`;
            }, 1000);
        }

    } catch (err) {
        console.error("Firebase Error:", err);
        showToast(`❌ Error: ${err.message}`, 'error');
    } finally {
        setLoading(false);
    }
}


// --- 6. INITIALIZATION AND LISTENERS ---

if (!familyKey) {
    showToast("❌ परिवार ID नहीं मिला। कृपया परिवार जोड़कर पुनः प्रयास करें।", 'error', 5000);
}


onAuthStateChanged(auth, (user) => {
    if (!user) {
        showToast("कृपया लॉगिन करें", 'info');
        setTimeout(() => {
            window.location.href = "../index.html";
        }, 3000);
        return;
    }

    currentUID = user.uid;

    fetchMemberData(currentUID);

    if (memberForm) {
        memberForm.addEventListener("submit", handleMemberSubmit);

        // Clear errors on input
        [aadhaarInput, nameInput, fatherNameInput, dobInput].forEach(input => {
            input.addEventListener('input', () => clearError(input));
        });
        genderFieldset.querySelectorAll('input[name="gender"]').forEach(input => {
             input.addEventListener('change', () => clearError(genderFieldset));
        });
        maritalFieldset.querySelectorAll('input[name="marital"]').forEach(input => {
             input.addEventListener('change', () => clearError(maritalFieldset));
        });
    }

    // Modal Button Listeners
    addAnotherMemberBtn.addEventListener('click', () => {
        toggleModal(false);
        // नए सदस्य के लिए पेज को सही ढंग से रीलोड करें
        window.location.href = `add_member.html?family=${familyKey}`;
    });

    finishSurveyBtn.addEventListener('click', () => {
        toggleModal(false);
        // Redirect to member list for this family
        window.location.href = `../showmember/show_member.html?family=${familyKey}`;
    });

});

// --- 7. GLOBAL STATUS LISTENERS ---

window.addEventListener("offline", () => {
    showToast("❌ इंटरनेट कनेक्शन नहीं है", 'error', 5000);
});

window.addEventListener("online", () => {
    showToast("✅ आप वापस ऑनलाइन हैं", 'success', 3000);
});