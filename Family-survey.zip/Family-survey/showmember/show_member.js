import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
    getDatabase,
    ref,
    onValue,
    remove
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import {
    getAuth,
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// !!! Replace with your actual Firebase configuration !!!
const firebaseConfig = {
    apiKey: "AIzaSyBrV_RYGOZqu_PBVDcbBJjmXxmUX4NEc5w",
    authDomain: "gvmm-57297.firebaseapp.com",
    databaseURL: "https://gvmm-57297-default-rtdb.firebaseio.com",
    projectId: "gvmm-57297",
    storageBucket: "gvmm-57297.appspot.com",
    messagingSenderId: "128465029455",
    appId: "1:128465029455:web:5fe5bf87f0364edb631d3a"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

// --- Global State and Elements ---
let allMembers = [];
const memberList = document.getElementById("memberList");
const searchInput = document.getElementById("searchInput");

// Get Family Key from URL
const params = new URLSearchParams(window.location.search);
const familyKey = params.get("family");

if (!familyKey) {
    // If no family key, show error and redirect
    showToast("❌ परिवार ID नहीं मिला। वापस रीडायरेक्ट कर रहे हैं।");
    setTimeout(() => window.location.href = "../showSurvey/show_survey.html", 3000);
    throw new Error("Missing family key");
}

// --- Utility Functions ---

/**
 * Displays a toast notification.
 */
function showToast(msg, duration = 3000) {
    const toast = document.getElementById("toast");
    if (!toast) return;

    clearTimeout(window.currentToastTimeout);

    toast.textContent = msg;
    toast.classList.add("show");

    window.currentToastTimeout = setTimeout(() => {
        toast.classList.remove("show");
    }, duration);
}

/**
 * Safely displays text, escaping HTML and replacing null/undefined with a dash.
 */
function safe(text) {
    if (typeof text !== "string" || !text.trim()) {
        return "—";
    }
    // Simple HTML escaping to prevent XSS
    return text.replace(/[&<>'"]/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;',
        "'": '&#039;', '"': '&quot;'
    }[c]));
}

// --- Rendering Logic ---

/**
 * Renders the list of member cards based on the filtered data.
 */
function render(filteredList) {
    memberList.innerHTML = "";

    if (filteredList.length === 0) {
        memberList.innerHTML = searchInput.value.trim() !== ''
            ? `<p class="loading-text">🔍 कोई मैचिंग सदस्य नहीं मिला</p>`
            : `<p class="loading-text">🗒️ इस परिवार में कोई सदस्य नहीं मिला।</p>`;
        return;
    }

    filteredList.forEach((member) => {
        const card = renderMemberCard(member.data, member.key, member.uid);
        memberList.appendChild(card);
    });
}


/**
 * Creates the HTML structure for a single member card.
 */
function renderMemberCard(data, key, uid) {
    const card = document.createElement("div");
    card.className = "member-card";
    // Data attribute for search functionality
    card.setAttribute("data-search", `${safe(data.name) || ""} ${safe(data.aadhaar) || ""}`.toLowerCase());

    // Basic Info
    card.innerHTML = `
        <p style="margin-bottom: 15px;"><strong>सदस्य का नाम:</strong> <span>${safe(data.name)}</span></p>
        <p><strong>पिता का नाम:</strong> <span>${safe(data.fatherName)}</span></p>
        <p><strong>आधार:</strong> <span>${safe(data.aadhaar)}</span></p>

        <button class="toggleBtn">🔽 Show More</button>

        <div class="more-details" style="display:none;">
            ${renderDetails(data)}
            <div class="action-buttons">
                <button onclick="window.editMember('${key}')">✏️ Edit</button>
                <button onclick="window.deleteMember('${uid}','${key}')">🗑️ Delete</button>
                <button onclick="window.shareMember('${key}')">📤 Share</button>
            </div>
        </div>
    `;

    // Add Toggle Listener
    const toggleBtn = card.querySelector(".toggleBtn");
    const details = card.querySelector(".more-details");

    toggleBtn.addEventListener("click", () => {
        const show = details.style.display === "flex"; // Note: Using 'flex' as defined in updated CSS
        details.style.display = show ? "none" : "flex";
        toggleBtn.textContent = show ? "🔽 Show More" : "🔼 Hide";
    });

    return card;
}

/**
 * Generates the HTML for the expandable details section.
 */
function renderDetails(data) {
    const fields = [
        ["जन्म तिथि", data.dob],
        ["लिंग", data.gender],
        ["वैवाहिक स्थिति", data.marital],
        ["शिक्षा", data.education],
        ["पेशा", data.occupation]
    ];
    return fields.map(([label, val]) => `<p><strong>${label}:</strong> <span>${safe(val)}</span></p>`).join("");
}

// --- Action Handlers (Made global for use in inline HTML) ---

window.editMember = (key) => {
    showToast("सदस्य को संपादित कर रहे हैं...");
    window.location.href = `../addmember/add_member.html?family=${familyKey}&member=${key}`;
};

window.deleteMember = (uid, key) => {
    if (confirm(`क्या आप वाकई इस सदस्य (ID: ${key.substring(0, 8)}...) को हटाना चाहते हैं?`)) {
        remove(ref(db, `surveys/members/${uid}/${familyKey}/${key}`))
            .then(() => showToast("🗑️ सदस्य सफलतापूर्वक हटा दिया गया", 3500))
            .catch((error) => {
                console.error(error);
                showToast("❌ सदस्य हटाने में विफल", 4000);
            });
    }
};

window.shareMember = (key) => {
    // Generates a link to the edit page for sharing or future deep linking
    const url = `${location.origin}/addmember/add_member.html?family=${familyKey}&member=${key}`;

    if (navigator.clipboard) {
        navigator.clipboard.writeText(url)
            .then(() => showToast("📎 लिंक कॉपी हो गया!", 3000))
            .catch(() => showToast("❌ लिंक कॉपी नहीं हो सका", 4000));
    } else {
        // Fallback for older browsers
        showToast("❌ आपका ब्राउज़र क्लिपबोर्ड एक्सेस का समर्थन नहीं करता है।");
    }
};

// --- Initialization and Event Listeners ---

onAuthStateChanged(auth, (user) => {
    if (!user) {
        showToast("⚠️ कृपया लॉगिन करें", 3000);
        setTimeout(() => window.location.href = "../index.html", 3000);
        return;
    }

    const uid = user.uid;
    const memberRef = ref(db, `surveys/members/${uid}/${familyKey}`);

    // Show initial loading state
    memberList.innerHTML = `<div class="loader"></div><p class="loading-text">🔄 डेटा लोड हो रहा है...</p>`;

    // Live data listener
    onValue(memberRef, (snapshot) => {
        allMembers = [];
        if (snapshot.exists()) {
            snapshot.forEach((childSnap) => {
                allMembers.push({ 
                    data: childSnap.val(), 
                    key: childSnap.key,
                    uid: uid // Pass UID to actions
                });
            });

            // Render the full list initially
            const val = searchInput.value.toLowerCase().trim();
            const filtered = allMembers.filter(m =>
                (m.data.name && m.data.name.toLowerCase().includes(val)) ||
                (m.data.aadhaar && m.data.aadhaar.toLowerCase().includes(val))
            );
            render(filtered);
            showToast("✅ सदस्य सूची अपडेट की गई", 1500);

        } else {
            allMembers = [];
            memberList.innerHTML = `<p class="loading-text">🗒️ इस परिवार में कोई सदस्य नहीं मिला।</p>`;
        }
    }, (error) => {
        console.error("Firebase Read Error:", error);
        memberList.innerHTML = `<p class="loading-text">❌ डेटा लोड करने में त्रुटि हुई</p>`;
    });

    // Search Listener
    searchInput.addEventListener("input", () => {
        const val = searchInput.value.toLowerCase().trim();
        const filtered = allMembers.filter(m =>
            (m.data.name && m.data.name.toLowerCase().includes(val)) ||
            (m.data.aadhaar && m.data.aadhaar.toLowerCase().includes(val))
        );
        render(filtered);
    });
});

// --- Network Status ---
window.addEventListener("offline", () => showToast("❌ इंटरनेट कनेक्शन नहीं है", 5000));
window.addEventListener("online", () => showToast("✅ आप वापस ऑनलाइन हैं", 3000));