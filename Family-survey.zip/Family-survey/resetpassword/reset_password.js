import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, confirmPasswordReset } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// --- 1. CONFIGURATION AND INITIALIZATION ---

// Firebase config
const firebaseConfig = {
    apiKey: "AIzaSyBrV_RYGOZqu_PBVDcbBJjmXxmUX4NEc5w",
    authDomain: "gvmm-57297.firebaseapp.com",
    projectId: "gvmm-57297",
    // Note: If you face issues, ensure databaseURL is included if required by your setup
    // databaseURL: "https://gvmm-57297-default-rtdb.firebaseio.com",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Constants and DOM Elements
const NEW_PASSWORD_INPUT = document.getElementById('newPassword');
const CONFIRM_PASSWORD_INPUT = document.getElementById('confirmPassword');
const RESET_FORM = document.getElementById('resetForm');
const SUBMIT_BTN = document.getElementById('submitBtn');
const TOAST = document.getElementById("toast");
const ERROR_CLASS = 'has-error';

// Get oobCode from URL
const urlParams = new URLSearchParams(window.location.search);
const oobCode = urlParams.get('oobCode');

// --- 2. UTILITY FUNCTIONS ---

/**
 * Displays a custom toast notification.
 */
function showToast(message, type = "info", duration = 4000) {
    if (!TOAST) return;

    // Clear any existing class before adding new ones
    TOAST.className = `toast ${type}`; 
    TOAST.textContent = message;

    setTimeout(() => TOAST.classList.add("show"), 50);
    setTimeout(() => TOAST.classList.remove("show"), duration);
}

/**
 * Manages the submit button's loading and disabled state, including A11Y attributes.
 * @param {boolean} loading - True to enter loading state, false to exit.
 */
function setLoading(loading) {
    if (!SUBMIT_BTN) return;

    SUBMIT_BTN.classList.toggle("loading", loading);
    SUBMIT_BTN.disabled = loading;
    SUBMIT_BTN.setAttribute("aria-busy", loading);
}

/**
 * Displays an error message and highlights the associated input's form group.
 * @param {HTMLElement} inputEl - The input element.
 * @param {string} message - The error message to display.
 */
function applyErrorState(inputEl, message) {
    const inputId = inputEl.id;
    const errorEl = document.getElementById(inputId + "Error");

    if (errorEl) {
        errorEl.textContent = message;
        inputEl.closest('.form-group')?.classList.add(ERROR_CLASS);
    }
}

/**
 * Clears all error messages and visual error states from the form.
 */
function clearErrors() {
    document.querySelectorAll(".error-message").forEach(el => el.textContent = "");
    NEW_PASSWORD_INPUT.closest('.form-group')?.classList.remove(ERROR_CLASS);
    CONFIRM_PASSWORD_INPUT.closest('.form-group')?.classList.remove(ERROR_CLASS);
}

// --- 3. VALIDATION LOGIC ---

/**
 * Strong Password Validator (Updated to be a bit more explicit in requirements)
 * Requires: minimum 8 characters, at least one uppercase letter (A-Z), 
 * at least one number (0-9), and at least one symbol (@$!%*?&).
 * Note: Added stricter regex than the original for better security.
 */
function validatePassword(pwd) {
    return {
        isValid: /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(pwd),
        message: "मज़बूत पासवर्ड दर्ज करें (कम से कम 8 कैरेक्टर, 1 कैपिटल, 1 नंबर, 1 चिन्ह)"
    };
}

/**
 * Handles all client-side validation for the form.
 */
function validateForm(newPassword, confirmPassword) {
    clearErrors();
    let isValid = true;

    const { isValid: isPwdStrong, message: pwdMessage } = validatePassword(newPassword);

    if (!newPassword) {
        applyErrorState(NEW_PASSWORD_INPUT, "पासवर्ड आवश्यक है");
        isValid = false;
    } else if (!isPwdStrong) {
        applyErrorState(NEW_PASSWORD_INPUT, pwdMessage);
        isValid = false;
    }

    if (!confirmPassword) {
        applyErrorState(CONFIRM_PASSWORD_INPUT, "पुष्टि आवश्यक है");
        isValid = false;
    } else if (newPassword !== confirmPassword) {
        applyErrorState(CONFIRM_PASSWORD_INPUT, "पासवर्ड मेल नहीं खाते हैं");
        isValid = false;
    }

    return isValid;
}

// --- 4. FIREBASE ERROR TRANSLATOR ---

/**
 * Friendly Error Translator (Updated to use object lookup for cleaner code)
 */
function getFriendlyError(code) {
    const errorMessages = {
        'auth/expired-action-code': "🔒 यह लिंक अब मान्य नहीं है। कृपया नया अनुरोध करें।",
        'auth/invalid-action-code': "⚠️ यह रीसेट लिंक गलत या पहले ही उपयोग हो चुका है।",
        'auth/user-disabled': "🚫 यह यूज़र निष्क्रिय कर दिया गया है।",
        'auth/weak-password': "⚠️ नया पासवर्ड बहुत कमज़ोर है।", // Added weak-password handler
        'auth/requires-recent-login': "🔐 सुरक्षा के लिए, आपको फिर से लॉगिन करना होगा।", // Standard Firebase error
    };
    return errorMessages[code] || "❌ कुछ गलत हुआ। कृपया पुनः प्रयास करें।";
}


// --- 5. INITIAL CHECK AND EVENT LISTENERS ---

// Initial check for oobCode
if (!oobCode) {
    showToast("❌ गलत या पुराना लिंक है।", 'error', 5000);
    // Use the error message element to permanently show the error on the screen
    document.getElementById('resetHeader').textContent = "❌ लिंक अमान्य";
    if (SUBMIT_BTN) SUBMIT_BTN.disabled = true;
    // Note: Instead of throwing an error, we show a message and disable the form.
}

// Setup Password Toggles (Copied logic from signup.js)
function setupToggle(btnId, inputId) {
    const btn = document.getElementById(btnId);
    const input = document.getElementById(inputId);
    if (btn && input) {
        btn.addEventListener("click", () => {
            const isPassword = input.type === "password";
            input.type = isPassword ? "text" : "password";

            const toggleIcon = btn.querySelector('.toggle-icon');
            if (toggleIcon) {
                toggleIcon.textContent = isPassword ? "🙈" : "👁️";
            }
            btn.setAttribute("aria-label", isPassword ? "Hide password" : "Show password");
            input.focus();
        });
    }
}

setupToggle("toggleNewPassword", "newPassword");
setupToggle("toggleConfirmPassword", "confirmPassword");


// Form Submission Handler
if (RESET_FORM) {
    RESET_FORM.addEventListener('submit', async (e) => {
        e.preventDefault();

        const newPassword = NEW_PASSWORD_INPUT.value;
        const confirmPassword = CONFIRM_PASSWORD_INPUT.value;

        if (!validateForm(newPassword, confirmPassword)) {
            // Focus on the first error
            if (document.getElementById('newPasswordError').textContent) {
                 NEW_PASSWORD_INPUT.focus();
            } else if (document.getElementById('confirmPasswordError').textContent) {
                CONFIRM_PASSWORD_INPUT.focus();
            }
            return;
        }

        setLoading(true);

        try {
            await confirmPasswordReset(auth, oobCode, newPassword);
            showToast("✅ पासवर्ड सफलतापूर्वक बदल दिया गया!", 'success');

            setTimeout(() => {
                // Redirect back to the login page
                window.location.href = "../index.html"; 
            }, 2000);

        } catch (error) {
            setLoading(false);
            const friendlyMessage = getFriendlyError(error.code);
            showToast(friendlyMessage, 'error', 5000);

            if (error.code === 'auth/weak-password') {
                applyErrorState(NEW_PASSWORD_INPUT, friendlyMessage);
                NEW_PASSWORD_INPUT.focus();
            }
        }
    });
}

// Live Validation (on input)
[NEW_PASSWORD_INPUT, CONFIRM_PASSWORD_INPUT].forEach(input => {
    if (input) {
        input.addEventListener("input", () => {
            // Clear error state instantly when user starts typing
            const inputId = input.id;
            document.getElementById(inputId + "Error").textContent = "";
            input.closest('.form-group')?.classList.remove(ERROR_CLASS);
        });
    }
});

// Network Status (Kept as is - great feature!)
window.addEventListener("offline", () => showToast("📴 इंटरनेट कनेक्शन नहीं है", 'error', 5000));
window.addEventListener("online", () => showToast("📶 आप ऑनलाइन हैं", 'success', 3000));