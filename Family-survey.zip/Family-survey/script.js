import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
    getAuth,
    signInWithEmailAndPassword,
    sendPasswordResetEmail,
    GoogleAuthProvider,
    GithubAuthProvider,
    signInWithPopup
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// --- 1. CONFIGURATION AND INITIALIZATION ---

// NOTE: In a production environment, you should load these keys securely 
// via environment variables or server-side rendering, not hardcoded here.
const firebaseConfig = {
    apiKey: "AIzaSyBrV_RYGOZqu_PBVDcbBJjmXxmUX4NEc5w",
    authDomain: "gvmm-57297.firebaseapp.com",
    databaseURL: "https://gvmm-57297-default-rtdb.firebaseio.com",
    projectId: "gvmm-57297",
    storageBucket: "gvmm-57297.appspot.com",
    messagingSenderId: "128465029455",
    appId: "1:128465029455:web:5fe5bf87f0364edb631d3a"
};

// Define the post-login destination as a constant
const DASHBOARD_URL = "dashboard/dashboard.html";

// Initialize Firebase services
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const githubProvider = new GithubAuthProvider();

// --- 2. DOM ELEMENTS ---

const loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("loginEmail");
const passwordInput = document.getElementById("loginPassword");
const togglePasswordBtn = document.getElementById("toggleLoginPassword");
const submitBtn = document.getElementById("submitBtn");
const emailError = document.getElementById("emailError");
const passwordError = document.getElementById("passwordError");
const forgotLink = document.getElementById("forgotPasswordLink");
const googleLoginBtn = document.getElementById("googleLogin");
const githubLoginBtn = document.getElementById("githubLogin");
const toast = document.getElementById("toast");

// --- 3. UTILITY AND VALIDATION FUNCTIONS ---

/**
 * Displays a custom toast notification.
 * @param {string} message - The message to display.
 * @param {string} type - The type of toast ('info', 'success', 'error').
 * @param {number} duration - How long the toast should stay visible in ms.
 */
function showToast(message, type = "info", duration = 4000) {
    if (!toast) return; // Safety check

    toast.textContent = message;
    toast.className = `toast ${type}`;

    setTimeout(() => toast.classList.add('show'), 50); // Small delay for CSS transition
    setTimeout(() => toast.classList.remove('show'), duration);
}

/**
 * Manages the submit button's loading and disabled state, including A11Y attributes.
 * @param {boolean} loading - True to enter loading state, false to exit.
 */
function setLoadingState(loading) {
    if (!submitBtn) return; // Safety check

    submitBtn.classList.toggle('loading', loading);
    submitBtn.disabled = loading;

    // Accessibility enhancement: Inform screen readers of the busy state
    submitBtn.setAttribute("aria-busy", loading);
    // Optional: add visual class to parent form-group to highlight inputs
    emailInput.closest('.form-group')?.classList.toggle('is-loading', loading);
    passwordInput.closest('.form-group')?.classList.toggle('is-loading', loading);
}

/**
 * Clears form-level error messages and highlights.
 */
function clearErrors() {
    emailError.textContent = '';
    passwordError.textContent = '';
    // Remove error classes from form-groups
    emailInput.closest('.form-group')?.classList.remove('has-error');
    passwordInput.closest('.form-group')?.classList.remove('has-error');
}

/**
 * Client-side email validation.
 */
function validateEmail(email) {
    // Standard RFC 5322 pattern (simplified)
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/**
 * Client-side password length validation.
 * NOTE: For improved security, consider a regex for strong passwords
 * (e.g., requiring one uppercase, one number, etc.)
 */
function validatePassword(password) {
    return password.length >= 6;
}

/**
 * Applies error styling to the form group.
 * @param {HTMLElement} errorElement - The <span> element where the message is displayed.
 */
function applyErrorState(inputElement, errorMessage) {
    const formGroup = inputElement.closest('.form-group');
    if (formGroup) {
        formGroup.classList.add('has-error');
    }
    const errorSpan = document.getElementById(`${inputElement.id.replace('login', '').toLowerCase()}Error`);
    if (errorSpan) {
        errorSpan.textContent = errorMessage;
    }
}

// --- 4. EVENT HANDLERS ---

// Main Email/Password Login
if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        clearErrors();

        let isValid = true;
        if (!email) {
            applyErrorState(emailInput, "Email is required");
            isValid = false;
        } else if (!validateEmail(email)) {
            applyErrorState(emailInput, "Please enter a valid email");
            isValid = false;
        }

        if (!password) {
            applyErrorState(passwordInput, "Password is required");
            isValid = false;
        } else if (!validatePassword(password)) {
            applyErrorState(passwordInput, "Password must be at least 6 characters");
            isValid = false;
        }

        if (!isValid) {
            // Focus on the first invalid input for better UX
            if (emailError.textContent) emailInput.focus();
            else if (passwordError.textContent) passwordInput.focus();
            return;
        }

        setLoadingState(true);

        try {
            await signInWithEmailAndPassword(auth, email, password);
            showToast("✅ Login successful! Redirecting...", "success");

            setTimeout(() => {
                window.location.href = DASHBOARD_URL;
            }, 2000);

        } catch (error) {
            console.error("Login error:", error);
            setLoadingState(false);

            const errorCode = error.code;
            const errorMessages = {
                "auth/wrong-password": "❌ Incorrect password",
                "auth/user-not-found": "❌ No account found with this email",
                "auth/invalid-email": "❌ Invalid email address",
                "auth/too-many-requests": "❌ Too many failed attempts. Try again later",
                "auth/network-request-failed": "❌ Network error. Check your connection",
                "auth/user-disabled": "❌ This account has been disabled"
            };

            const displayMessage = errorMessages[errorCode] || `❌ Login failed: ${error.message}`;
            showToast(displayMessage, "error");

            // Apply specific error state highlighting
            if (errorCode === "auth/wrong-password") {
                applyErrorState(passwordInput, "Incorrect password");
                passwordInput.focus();
            } else if (errorCode === "auth/user-not-found" || errorCode === "auth/invalid-email") {
                applyErrorState(emailInput, "No account found with this email");
                emailInput.focus();
            }
        }
    });
}

// Password visibility toggle
if (togglePasswordBtn && passwordInput) {
    togglePasswordBtn.addEventListener("click", () => {
        const isPassword = passwordInput.type === "password";
        passwordInput.type = isPassword ? "text" : "password";

        // Toggle icon and ARIA label
        const toggleIcon = togglePasswordBtn.querySelector(".toggle-icon");
        if (toggleIcon) {
            toggleIcon.textContent = isPassword ? "🙈" : "👁️";
        }

        togglePasswordBtn.setAttribute("aria-label",
            isPassword ? "Hide password" : "Show password"
        );
        passwordInput.focus(); // Keep focus on input after toggling
    });
}

// Forgot password functionality
if (forgotLink) {
    forgotLink.addEventListener("click", async (e) => {
        e.preventDefault();

        const email = emailInput.value.trim();
        clearErrors();

        if (!email || !validateEmail(email)) {
            applyErrorState(emailInput, "Please enter a valid email address first");
            showToast("❗ Please enter a valid email address first", "info");
            emailInput.focus();
            return;
        }

        try {
            await sendPasswordResetEmail(auth, email);
            showToast(`📩 Password reset link sent to ${email}`, "success", 5000);
        } catch (error) {
            console.error("Password reset error:", error);
            const errorMessage = (error.code === 'auth/user-not-found') 
                ? "❌ Email not registered." 
                : "❌ Failed to send reset email. Try again later.";
            showToast(errorMessage, "error");
        }
    });
}

// Social Login Handlers (Refactored to a single function for DRY principle)
async function handleSocialLogin(provider) {
    try {
        await signInWithPopup(auth, provider);
        showToast("✅ Login successful! Redirecting...", "success");
        setTimeout(() => {
            window.location.href = DASHBOARD_URL;
        }, 2000);
    } catch (error) {
        if (error.code !== 'auth/popup-closed-by-user') {
            console.error("Social login failed:", error);
            showToast(`❌ ${provider.providerId.split('.')[0]} login failed`, "error");
        }
    }
}

if (googleLoginBtn) {
    googleLoginBtn.addEventListener("click", () => handleSocialLogin(googleProvider));
}

if (githubLoginBtn) {
    githubLoginBtn.addEventListener("click", () => handleSocialLogin(githubProvider));
}

// Real-time input validation (on blur and input)
if (emailInput) {
    emailInput.addEventListener("blur", () => {
        const email = emailInput.value.trim();
        if (email && !validateEmail(email)) {
            applyErrorState(emailInput, "Please enter a valid email address");
        } else {
            // Only clear the error state if there is no error
            emailInput.closest('.form-group')?.classList.remove('has-error');
            emailError.textContent = "";
        }
    });

    emailInput.addEventListener("input", () => {
        // Clear error message/state instantly when user starts typing
        if (emailError.textContent) {
            emailError.textContent = "";
            emailInput.closest('.form-group')?.classList.remove('has-error');
        }
    });
}

if (passwordInput) {
    passwordInput.addEventListener("blur", () => {
        const password = passwordInput.value.trim();
        if (password && !validatePassword(password)) {
            applyErrorState(passwordInput, "Password must be at least 6 characters");
        } else {
            // Only clear the error state if there is no error
            passwordInput.closest('.form-group')?.classList.remove('has-error');
            passwordError.textContent = "";
        }
    });

    passwordInput.addEventListener("input", () => {
        // Clear error message/state instantly when user starts typing
        if (passwordError.textContent) {
            passwordError.textContent = "";
            passwordInput.closest('.form-group')?.classList.remove('has-error');
        }
    });
}

// Network status monitoring (Good addition!)
window.addEventListener("offline", () => {
    setLoadingState(false); // Stop any loading process if network fails
    showToast("❌ No internet connection", "error", 10000);
});

window.addEventListener("online", () => {
    showToast("✅ Internet connection restored!", "success");
});

// Auto-focus email input on page load
window.addEventListener("load", () => {
    if (emailInput) emailInput.focus();
});

// Optional: Enhanced error handling for Firebase auth state (Already present)
/*
auth.onAuthStateChanged((user) => {
    if (user) {
        console.log("User is signed in:", user.email);
    }
});
*/