import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
    getAuth,
    createUserWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
    getDatabase,
    ref,
    set
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";

// --- 1. CONFIGURATION AND INITIALIZATION ---

// NOTE: Please ensure these keys are loaded securely in a production environment.
const firebaseConfig = {
    apiKey: "AIzaSyBrV_RYGOZqu_PBVDcbBJjmXxmUX4NEc5w",
    authDomain: "gvmm-57297.firebaseapp.com",
    databaseURL: "https://gvmm-57297-default-rtdb.firebaseio.com",
    projectId: "gvmm-57297",
    storageBucket: "gvmm-57297.appspot.com",
    messagingSenderId: "128465029455",
    appId: "1:128465029455:web:5fe5bf87f0364edb631d3a"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

// Constants
const DASHBOARD_URL = "../dashboard/dashboard.html";
const ERROR_CLASS = 'has-error'; // Matching the upgraded CSS class

// --- 2. DOM ELEMENTS ---

const signupForm = document.getElementById("signupForm");
const submitBtn = document.getElementById("submitBtn");
const toast = document.getElementById("toast");

const firstNameInput = document.getElementById("firstName");
const lastNameInput = document.getElementById("lastName");
const emailInput = document.getElementById("signupEmail");
const passwordInput = document.getElementById("signupPassword");
const confirmPasswordInput = document.getElementById("confirmPassword");
const termsAgreementInput = document.getElementById("termsAgreement");

// --- 3. UTILITY FUNCTIONS ---

/**
 * Initializes password visibility toggle functionality with A11Y features.
 * @param {string} btnId - ID of the toggle button.
 * @param {string} inputId - ID of the password input field.
 */
function setupToggle(btnId, inputId) {
    const btn = document.getElementById(btnId);
    const input = document.getElementById(inputId);
    if (btn && input) {
        btn.addEventListener("click", () => {
            const isPassword = input.type === "password";
            input.type = isPassword ? "text" : "password";

            // A11Y and visual update
            btn.setAttribute("aria-label", isPassword ? "Hide password" : "Show password");
            btn.querySelector('.toggle-icon').textContent = isPassword ? "🙈" : "👁️";
            input.focus();
        });
    }
}

// Setup toggles for both password fields
setupToggle("toggleSignupPassword", "signupPassword");
setupToggle("toggleConfirmPassword", "confirmPassword");

/**
 * Displays a custom toast notification.
 */
function showToast(message, type = "info", duration = 3000) {
    if (!toast) return;

    toast.textContent = message;
    toast.className = `toast ${type}`;
    setTimeout(() => toast.classList.add("show"), 50); // Small delay for CSS transition
    setTimeout(() => toast.classList.remove("show"), duration);
}

/**
 * Manages the submit button's loading and disabled state, including A11Y attributes.
 * @param {boolean} loading - True to enter loading state, false to exit.
 */
function setLoading(loading) {
    if (!submitBtn) return;

    submitBtn.classList.toggle("loading", loading);
    submitBtn.disabled = loading;
    // Accessibility enhancement: Inform screen readers of the busy state
    submitBtn.setAttribute("aria-busy", loading);
}

/**
 * Clears all error messages and visual error states from the form.
 */
function clearErrors() {
    // Select all elements that display errors
    document.querySelectorAll(".error-message").forEach(el => el.textContent = "");
    // Remove error class from all form groups
    document.querySelectorAll(".form-group").forEach(el => el.classList.remove(ERROR_CLASS));
}

/**
 * Displays an error message and highlights the associated input's form group.
 * @param {string} inputId - The ID of the input element (e.g., 'firstName', 'signupPassword').
 * @param {string} message - The error message to display.
 */
function applyErrorState(inputId, message) {
    const errorEl = document.getElementById(inputId + "Error");
    if (errorEl) {
        errorEl.textContent = message;
        // Find the closest parent form-group and add the error class
        const inputEl = document.getElementById(inputId);
        if (inputEl) {
            inputEl.closest('.form-group')?.classList.add(ERROR_CLASS);
        } else if (inputId === 'terms') {
            // Special handling for terms agreement which is not an input
            document.querySelector('.terms-group')?.classList.add(ERROR_CLASS);
        }
    }
}

// --- 4. VALIDATION LOGIC ---

/**
 * Validates the form data locally.
 * NOTE: Regular expressions added for stricter validation matching standard practices.
 */
function validateForm(data) {
    const errors = {};
    const nameRegex = /^[A-Za-z]{2,}$/;
    const emailRegex = /^\S+@\S+\.\S+$/;

    if (!nameRegex.test(data.firstName.trim())) {
        errors.firstName = "First name must be at least 2 letters";
    }

    if (!nameRegex.test(data.lastName.trim())) {
        errors.lastName = "Last name must be at least 2 letters";
    }

    if (!data.email) {
        errors.email = "Email required";
    } else if (!emailRegex.test(data.email)) {
        errors.email = "Invalid email format";
    }

    if (!data.password) {
        errors.password = "Password required";
    } else if (data.password.length < 6) {
        errors.password = "Must be at least 6 characters";
    }

    if (!data.confirmPassword) {
        errors.confirmPassword = "Confirm password required";
    } else if (data.password !== data.confirmPassword) {
        errors.confirmPassword = "Passwords do not match";
    }

    if (!data.termsAgreed) {
        errors.terms = "Agreement to terms is required";
    }

    return errors;
}

// --- 5. EVENT LISTENERS ---

// Form submission handler
if (signupForm) {
    signupForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const formData = {
            firstName: firstNameInput.value,
            lastName: lastNameInput.value,
            email: emailInput.value,
            password: passwordInput.value,
            confirmPassword: confirmPasswordInput.value,
            termsAgreed: termsAgreementInput.checked
        };

        clearErrors();

        const errors = validateForm(formData);
        if (Object.keys(errors).length > 0) {
            Object.entries(errors).forEach(([key, message]) => {
                // Use the updated applyErrorState function
                applyErrorState(key, message);
            });
            // Focus on the first error input for better UX
            const firstErrorKey = Object.keys(errors)[0];
            document.getElementById(firstErrorKey)?.focus();
            return;
        }

        setLoading(true);

        try {
            // 1. Create User in Firebase Authentication
            const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
            const user = userCredential.user;

            // 2. Save User Data to Realtime Database
            const userRef = ref(db, "users/" + user.uid);
            await set(userRef, {
                firstName: formData.firstName.trim(),
                lastName: formData.lastName.trim(),
                fullName: `${formData.firstName.trim()} ${formData.lastName.trim()}`, // Use a combined name field
                email: formData.email,
                createdAt: new Date().toISOString()
            });

            showToast("✅ Account created! Redirecting...", "success");
            setTimeout(() => window.location.href = DASHBOARD_URL, 2000);

        } catch (error) {
            setLoading(false);
            console.error("Signup error:", error);

            const errorCode = error.code;
            const messages = {
                "auth/email-already-in-use": "❌ Email already registered. Try signing in.",
                "auth/invalid-email": "❌ Invalid email format. Check your input.",
                "auth/weak-password": "❌ Password too weak. Use a stronger one.",
                "auth/network-request-failed": "❌ Network error. Please check your connection."
            };

            const displayMessage = messages[errorCode] || "❌ Signup failed. Please try again.";
            showToast(displayMessage, "error");

            // Highlight specific fields based on Firebase error
            if (errorCode === "auth/email-already-in-use" || errorCode === "auth/invalid-email") {
                applyErrorState('signupEmail', displayMessage);
                emailInput.focus();
            } else if (errorCode === "auth/weak-password") {
                applyErrorState('signupPassword', "Password is too weak. Must be at least 6 characters.");
                passwordInput.focus();
            }
        }
    });
}

// --- Live Input Validation Management ---

const inputFields = [firstNameInput, lastNameInput, emailInput, passwordInput, confirmPasswordInput];

inputFields.forEach(input => {
    if (input) {
        // Clear error on input
        input.addEventListener("input", () => {
            const inputId = input.id.replace('signup', '');
            document.getElementById(inputId + "Error").textContent = "";
            input.closest('.form-group')?.classList.remove(ERROR_CLASS);
        });

        // Validation on blur (optional: can be noisy, but good for immediate feedback)
        input.addEventListener("blur", () => {
             const formData = {
                firstName: firstNameInput.value,
                lastName: lastNameInput.value,
                email: emailInput.value,
                password: passwordInput.value,
                confirmPassword: confirmPasswordInput.value,
                termsAgreed: termsAgreementInput.checked
            };

            const errors = validateForm(formData);
            const inputId = input.id.replace('signup', '');

            // Only show the error related to the current input on blur
            if (errors[inputId]) {
                applyErrorState(inputId, errors[inputId]);
            } else if (inputId === 'password' && errors.confirmPassword) {
                // If password is valid but confirmation is not, show confirmation error
                applyErrorState('confirmPassword', errors.confirmPassword);
            }
        });
    }
});

if (termsAgreementInput) {
     termsAgreementInput.addEventListener('change', () => {
        if (termsAgreementInput.checked) {
            document.querySelector('.terms-group')?.classList.remove(ERROR_CLASS);
            document.getElementById('termsError').textContent = "";
        }
    });
}

// Network status (Kept as is - great feature!)
window.addEventListener("offline", () => {
    setLoading(false); // Stop loading if network fails
    showToast("❌ No internet connection", "error", 5000);
});
window.addEventListener("online", () => showToast("✅ Back online", "success"));

// Auto-focus (Kept as is)
window.addEventListener("load", () => {
    if (firstNameInput) firstNameInput.focus();
});