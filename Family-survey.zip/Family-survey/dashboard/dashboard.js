import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getDatabase, ref, get, child, update } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import { getAuth, onAuthStateChanged, signOut, updateProfile } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// --- 1. CONFIGURATION AND INITIALIZATION ---

// Firebase config (Kept as is)
const firebaseConfig = {
    apiKey: "AIzaSyBrV_RYGOZqu_PBVDcbBJjmXxmUX4NEc5w",
    authDomain: "gvmm-57297.firebaseapp.com",
    databaseURL: "https://gvmm-57297-default-rtdb.firebaseio.com",
    projectId: "gvmm-57297",
    storageBucket: "gvmm-57297.appspot.com",
    messagingSenderId: "128465029455",
    appId: "1:128465029455:web:5fe5bf87f0364edb631d3a"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

// --- 2. UI ELEMENTS & CONSTANTS ---

// Dashboard Elements
const loader = document.getElementById("loader");
const loadingText = document.getElementById("loadingText");
const searchInput = document.getElementById("searchInput");
const clearBtn = document.getElementById("clearBtn");
const searchResults = document.getElementById("searchResults");
const toast = document.getElementById("toast");
const ERROR_CLASS = 'has-error';

// Profile Elements
const profileToggleBtn = document.getElementById("profileToggleBtn");
const profileDetailsContainer = document.getElementById("profileDetailsContainer");
const editUsernameInput = document.getElementById("editUsername");
const editBtn = document.getElementById("editBtn");
const saveBtn = document.getElementById("saveBtn"); 
const logoutBtn = document.getElementById("logoutBtn");
const profileEditForm = document.getElementById("profileEditForm");

let isEditing = false; // State variable for edit mode
let allFamiliesData = {}; // Cache for search data

// --- 3. UTILITY FUNCTIONS ---

/**
 * Shows the loading spinner and text (uses the 'hidden' attribute).
 */
function showLoader() {
    loader?.removeAttribute("hidden");
    loadingText?.removeAttribute("hidden");
}

/**
 * Hides the loading spinner and text (uses the 'hidden' attribute).
 */
function hideLoader() {
    loader?.setAttribute("hidden", "");
    loadingText?.setAttribute("hidden", "");
}

/**
 * Displays a toast notification with a specific type.
 * @param {string} msg - The message to display.
 * @param {string} type - 'success', 'error', or 'info'.
 * @param {number} duration - Duration in ms.
 */
function showToast(msg, type = "info", duration = 3000) {
    if (!toast) return;

    toast.textContent = msg;
    // Apply type class for styling
    toast.className = `toast ${type}`;

    // Ensure screen reader gets the message (role="status" on the element handles this)
    setTimeout(() => toast.classList.add("show"), 50); 
    setTimeout(() => toast.classList.remove("show"), duration);
}

/**
 * Clears errors from a specific input field.
 */
function clearError(inputEl) {
    inputEl.closest('.form-group')?.classList.remove(ERROR_CLASS);
    // Ensure the error element exists before trying to set textContent
    const errorEl = document.getElementById(inputEl.id + "Error");
    if (errorEl) {
        errorEl.textContent = "";
    }
}

/**
 * Applies visual error state to an input and displays the message.
 */
function applyErrorState(inputEl, message) {
    inputEl.closest('.form-group')?.classList.add(ERROR_CLASS);
    // Ensure the error element exists
    const errorEl = document.getElementById(inputEl.id + "Error");
    if (errorEl) {
        errorEl.textContent = message;
    }
    inputEl.focus();
}

/**
 * Sets loading state for the Save button.
 */
function setLoading(loading) {
    saveBtn.classList.toggle("loading", loading);
    saveBtn.disabled = loading;
    saveBtn.setAttribute("aria-busy", loading);
    // Disable edit button too while saving is in progress
    editBtn.disabled = loading; 
}


// --- 4. PROFILE MANAGEMENT LOGIC ---

/**
 * Toggles the visibility of the profile details container (A11Y compliant).
 */
function toggleProfileDetails() {
    const isHidden = profileDetailsContainer.hasAttribute('hidden');

    if (isHidden) {
        profileDetailsContainer.removeAttribute('hidden');
        profileToggleBtn.setAttribute('aria-expanded', 'true');
    } else {
        profileDetailsContainer.setAttribute('hidden', '');
        profileToggleBtn.setAttribute('aria-expanded', 'false');
    }
}

/**
 * Toggles the profile section between view and edit mode.
 * @param {boolean} edit - True to enter edit mode, false to exit.
 */
function toggleEditMode(edit) {
    isEditing = edit;

    // Toggle button visibility
    editBtn.style.display = edit ? 'none' : 'inline-block';
    saveBtn.style.display = edit ? 'inline-block' : 'none';

    // Toggle input state and form class
    editUsernameInput.disabled = !edit;
    editUsernameInput.setAttribute('aria-disabled', !edit);

    if (edit) {
        // Switch to edit mode styles
        profileEditForm.classList.add('edit-mode');
        editUsernameInput.focus();
    } else {
        // Switch to view mode styles
        profileEditForm.classList.remove('edit-mode');
        // Clear potential unsaved changes on exit (if not saved)
        if (auth.currentUser) {
            editUsernameInput.value = auth.currentUser.displayName || "User";
        }
    }
}

/**
 * Handles saving the new username to Firebase Auth and RTDB.
 */
async function handleProfileSave(e) {
    e.preventDefault();
    const user = auth.currentUser;
    if (!user) return;

    const newUsername = editUsernameInput.value.trim();
    if (!newUsername || newUsername.length < 2) {
        applyErrorState(editUsernameInput, "नाम 2 कैरेक्टर से छोटा नहीं हो सकता");
        return;
    }
    clearError(editUsernameInput);

    // Only update if the name has actually changed
    if (newUsername === user.displayName) {
        showToast("प्रोफ़ाइल अपडेट की गई", 'info');
        toggleEditMode(false);
        return;
    }

    try {
        setLoading(true);

        // 1. Update Firebase Authentication Profile
        await updateProfile(user, { displayName: newUsername });

        // 2. Update Realtime Database Profile (User Data)
        const userRef = ref(db, `users/${user.uid}`);
        await update(userRef, { fullName: newUsername });

        // Success Feedback
        showToast("✅ नाम सफलतापूर्वक बदल दिया गया!", 'success');
        toggleEditMode(false);

    } catch (error) {
        console.error("Profile update error:", error);
        showToast("❌ प्रोफ़ाइल अपडेट विफल रही", 'error');
    } finally {
        setLoading(false);
    }
}

function updateStats(families, members, males, females) {
    const tf = document.getElementById("totalFamilies");
    const tm = document.getElementById("totalMembers");
    const tml = document.getElementById("totalMales");
    const tfl = document.getElementById("totalFemales");

    if (tf) tf.innerText = families;
    if (tm) tm.innerText = members;
    if (tml) tml.innerText = males;
    if (tfl) tfl.innerText = females;
}



async function loadDashboard(uid) {
    showLoader();

    try {
        const familySnap = await get(ref(db, `surveys/families/${uid}`));
        const memberSnap = await get(ref(db, `surveys/members/${uid}`));

        let totalFamilies = 0;
        let totalMembers = 0;
        let maleCount = 0;
        let femaleCount = 0;

        // ---- Families ----
        if (familySnap.exists()) {
            const familiesObj = familySnap.val();
            totalFamilies = Object.keys(familiesObj).length;

            allFamiliesData = Object.entries(familiesObj).map(
                ([key, value]) => ({ key, ...value })
            );
        } else {
            allFamiliesData = [];
        }

        // ---- Members ----
        if (memberSnap.exists()) {
            const familyMembers = memberSnap.val(); // familyKey level

            Object.values(familyMembers).forEach(membersObj => {
                if (!membersObj) return;

                const members = Object.values(membersObj);
                totalMembers += members.length;

                members.forEach(m => {
                    const g = String(m.gender || "").toLowerCase();

                    if (g === "male" || g.includes("पुर")) maleCount++;
                    else if (g === "female" || g.includes("मह")) femaleCount++;
                });
            });
        }

        updateStats(totalFamilies, totalMembers, maleCount, femaleCount);

    } catch (e) {
        console.error("Dashboard Error:", e);
        showToast("❌ Firebase डेटा पढ़ने में समस्या है", "error");
    } finally {
        hideLoader();
    }
}


// --- 6. SEARCH SYSTEM ---

/**
 * Setup Search System (Uses cached data)
 */
function setupSearch() {
    searchInput.addEventListener("input", handleSearchInput);
    clearBtn.addEventListener("click", handleClearSearch);
}

/**
 * Handles the search input event.
 */
function handleSearchInput() {
    let val = searchInput.value.toLowerCase().trim();

    // Show/Hide Clear button
    clearBtn.style.display = val ? 'block' : 'none';

    if (!val) {
        searchResults.innerHTML = "";
        return;
    }

    const filtered = allFamiliesData.filter(f =>
        // Search by Family Name or JanAadhar
        String(f.familyName || "").toLowerCase().includes(val) ||
        String(f.janAadhar || "").toLowerCase().includes(val)
    );

    renderSearchResults(filtered);
}

/**
 * Clears the search input and results.
 */
function handleClearSearch() {
    searchInput.value = "";
    searchResults.innerHTML = "";
    clearBtn.style.display = 'none'; // Hide clear button when empty
    searchInput.focus();
}

/**
 * Render Result Cards
 */
function renderSearchResults(list) {
    searchResults.innerHTML = "";

    if (list.length === 0) {
        searchResults.innerHTML = `<p style="text-align:center; color:#888;">कोई परिणाम नहीं मिला</p>`;
        return;
    }

    list.forEach(f => {
        const card = document.createElement("a");
        // Use the family key (f.key) or janAadhar to ensure a unique link
        card.href = `../showSurvey/show_survey.html?familyId=${f.janAadhar || f.key || ''}`; 
        card.className = "member-card";
        card.setAttribute('aria-label', `परिवार: ${f.familyName}, जन आधार: ${f.janAadhar}`);

        // Determine member count for display
        let displayMembers = '0';
        if (f.members) {
            displayMembers = Object.values(f.members).length;
        } else if (f.pariwarSankhya) {
             displayMembers = f.pariwarSankhya;
        }


        card.innerHTML = `
            <div class="card-info">
                <p class="family-name"><strong>परिवार:</strong> ${f.familyName || 'N/A'}</p>
                <p><strong>जन आधार:</strong> ${f.janAadhar || 'N/A'}</p>
            </div>
            <div class="card-stats">
                <p><strong>सदस्य:</strong> ${displayMembers}</p>
            </div>
        `;

        searchResults.appendChild(card);
    });
}

// --- 7. INITIALIZATION AND EVENT BINDING ---

// Logged-in check & Initial Load
onAuthStateChanged(auth, async (user) => {
    if (!user) {
        showToast("कृपया लॉगिन करें", 'info');
        setTimeout(() => (window.location.href = "../index.html"), 2000);
        return;
    }

    const uid = user.uid;
    // Format date in Indian style (DD/MM/YYYY)
    const creationDate = new Date(user.metadata.creationTime).toLocaleDateString('hi-IN');

    // Initialize Profile Data
    document.getElementById("editUsername").value = user.displayName || "User";
    document.getElementById("displayEmail").innerText = user.email || "--";
    document.getElementById("joinedDate").innerText = creationDate || "--";

    // Bind Profile Actions
    profileToggleBtn.addEventListener("click", toggleProfileDetails);
    editBtn.addEventListener("click", () => toggleEditMode(true));
    // The save button functionality is bound to the form submission
    profileEditForm.addEventListener("submit", handleProfileSave);

    // Bind Logout
    logoutBtn.addEventListener("click", () => {
        signOut(auth).then(() => {
            showToast("Logout हो रहे हैं...", 'info');
            setTimeout(() => {
                window.location.href = "../index.html";
            }, 1500);
        }).catch((error) => {
             console.error("Logout failed:", error);
             showToast("❌ लॉगआउट विफल", 'error');
        });
    });

    // Fetch Dashboard Data
    loadDashboard(uid);
});

// Network status events
window.addEventListener("offline", () => showToast("📴 इंटरनेट कनेक्शन नहीं है", 'error', 5000));
window.addEventListener("online", () => showToast("📶 आप ऑनलाइन हैं", 'success', 3000));