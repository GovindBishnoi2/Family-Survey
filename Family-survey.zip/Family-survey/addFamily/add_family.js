import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getDatabase, ref, push, set } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// --- 1. CONFIGURATION AND INITIALIZATION ---

const firebaseConfig = {
    apiKey: "AIzaSyBrV_RYGOZqu_PBVDcbBJjmXxmUX4NEc5w",
    authDomain: "gvmm-57297.firebaseapp.com",
    databaseURL: "https://gvmm-57297-default-rtdb.firebaseio.com",
    projectId: "gvmm-57297",
    storageBucket: "gvmm-57297.appspot.com",
    messagingSenderId: "128465029455",
    appId: "1:128465029455:web:5fe5bf87f0364edb631d3a"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

// --- 2. UI ELEMENTS AND CONSTANTS ---

const familyForm = document.getElementById("familyForm");
const addFamilyBtn = document.getElementById("addFamilyBtn");
const toast = document.getElementById("toast");
const ERROR_CLASS = 'has-error';

// Modal Elements
const actionModal = document.getElementById("actionModal");
const addMemberBtn = document.getElementById("addMemberBtn");
const addNewFamilyBtn = document.getElementById("addNewFamilyBtn");

// Input elements
const familyNameInput = document.getElementById("familyName");
const janAadharInput = document.getElementById("janAadhar");
const mobileInput = document.getElementById("mobile");
const pariwarSankhyaInput = document.getElementById("pariwarSankhya");

// Global variable to store the key of the successfully saved family
let currentFamilyKey = null;

// --- 3. UTILITY FUNCTIONS ---

/**
 * Displays a toast notification with a specific type and duration.
 */
function showToast(message, type = "info", duration = 3000) {
    if (!toast) return;

    clearTimeout(window.currentToastTimeout);

    toast.className = `toast ${type}`;
    toast.textContent = message;

    setTimeout(() => toast.classList.add("show"), 50); 

    window.currentToastTimeout = setTimeout(() => {
        toast.classList.remove("show");
    }, duration);
}

/**
 * Sets the loading state on the submit button.
 */
function setLoading(isLoading) {
    if (!addFamilyBtn) return;

    addFamilyBtn.disabled = isLoading;
    addFamilyBtn.classList.toggle("loading", isLoading);
    addFamilyBtn.setAttribute("aria-busy", isLoading);
}

/**
 * Applies visual error state to an input and displays the message.
 */
function applyErrorState(inputEl, message) {
    inputEl.closest('.form-group')?.classList.add(ERROR_CLASS);
    const errorEl = document.getElementById(inputEl.id + "Error");
    if (errorEl) {
        errorEl.textContent = message;
    }
}

/**
 * Clears error state from a specific input field.
 */
function clearError(inputEl) {
    inputEl.closest('.form-group')?.classList.remove(ERROR_CLASS);
    const errorEl = document.getElementById(inputEl.id + "Error");
    if (errorEl) {
        errorEl.textContent = "";
    }
}

/**
 * Clears all form inputs and error messages.
 */
function resetForm() {
    familyForm.reset();
    // Clear error states for a clean slate
    clearError(familyNameInput);
    clearError(janAadharInput);
    clearError(mobileInput);
    clearError(pariwarSankhyaInput);
}

/**
 * Helper function to show and hide the modal
 */
function toggleModal(show) {
    if (actionModal) {
        actionModal.classList.toggle('visible', show);
    }
}


// --- 4. VALIDATION AND SUBMISSION LOGIC ---

/**
 * Performs detailed validation and saves the family data.
 */
async function handleFormSubmit(e, uid) {
    e.preventDefault(); 
    setLoading(true);

    // Clear previous error messages (DO NOT reset inputs here)
    clearError(familyNameInput);
    clearError(janAadharInput);
    clearError(mobileInput);
    clearError(pariwarSankhyaInput);

    // Retrieve current values
    const familyName = familyNameInput.value.trim();
    const janAadhar = janAadharInput.value.trim();
    const mobile = mobileInput.value.trim();
    const pariwarSankhya = pariwarSankhyaInput.value.trim();

    const onlyDigits10 = /^\d{10}$/;
    let hasError = false;

    // Validation checks
    if (!familyName) {
        applyErrorState(familyNameInput, "कृपया परिवार के मुखिया का नाम दर्ज करें।");
        hasError = true;
    }

    const parsedSankhya = Number(pariwarSankhya);
    if (!pariwarSankhya || isNaN(parsedSankhya) || parsedSankhya <= 0 || !Number.isInteger(parsedSankhya)) {
        applyErrorState(pariwarSankhyaInput, "सदस्यों की संख्या एक पूर्ण संख्या (1 या उससे अधिक) होनी चाहिए।");
        hasError = true;
    }

    if (!onlyDigits10.test(janAadhar)) {
        applyErrorState(janAadharInput, "जन आधार नंबर 10 अंकों का होना चाहिए।");
        hasError = true;
    }

    if (!onlyDigits10.test(mobile)) {
        applyErrorState(mobileInput, "मोबाइल नंबर 10 अंकों का होना चाहिए।");
        hasError = true;
    }

    if (hasError) {
        setLoading(false);
        showToast("❌ कृपया सभी फ़ील्ड सही से भरें।", 'error', 4000); 
        return;
    }

    const data = {
        familyName,
        janAadhar,
        mobile,
        pariwarSankhya: parsedSankhya,
        timestamp: Date.now()
    };

    try {
        const familyRef = push(ref(db, `surveys/families/${uid}`));
        await set(familyRef, data);

        // Store the key and show success message
        currentFamilyKey = familyRef.key;
        showToast("✅ परिवार सफलतापूर्वक जोड़ा गया!", 'success', 3000);

        // Show the choice modal instead of redirecting
        toggleModal(true);

    } catch (error) {
        console.error("Firebase Error:", error);
        showToast(`❌ डेटा सेव करने में त्रुटि हुई: ${error.message}`, 'error', 5000); 
    } finally {
        setLoading(false);
    }
}


// --- 5. INITIALIZATION AND EVENT LISTENERS ---

// Listener for "Add Member in Current Family"
if (addMemberBtn) {
    addMemberBtn.addEventListener('click', () => {
        if (currentFamilyKey) {
            window.location.href = `../addmember/add_member.html?family=${currentFamilyKey}`;
        } else {
            showToast("त्रुटि: परिवार कुंजी नहीं मिली।", 'error', 3000);
            toggleModal(false);
        }
    });
}

// Listener for "Add New Family"
if (addNewFamilyBtn) {
    addNewFamilyBtn.addEventListener('click', () => {
        // Hide modal, clear the form, and reset the key
        toggleModal(false);
        resetForm();
        currentFamilyKey = null;
        showToast("फॉर्म साफ़ कर दिया गया है। नया परिवार दर्ज करें।", 'info', 3000);
    });
}

// Auth State Check
onAuthStateChanged(auth, (user) => {
    if (!user) {
        showToast("कृपया लॉगिन करें", 'info');
        setTimeout(() => {
            window.location.href = "../index.html";
        }, 3000);
        return;
    }

    const uid = user.uid;

    if (familyForm) {
        familyForm.addEventListener("submit", (e) => handleFormSubmit(e, uid));
    } else {
        console.error("Error: familyForm element not found.");
    }

    // Clear errors when the user starts typing
    [familyNameInput, janAadharInput, mobileInput, pariwarSankhyaInput].forEach(input => {
        input.addEventListener('input', () => clearError(input));
    });
});

// Network status handlers
window.addEventListener("offline", () => {
    showToast("❌ इंटरनेट कनेक्शन नहीं है", 'error', 5000);
});

window.addEventListener("online", () => {
    showToast("✅ आप वापस ऑनलाइन हैं", 'success', 3000);
});